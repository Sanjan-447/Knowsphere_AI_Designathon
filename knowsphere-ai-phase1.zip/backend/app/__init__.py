"""
Flask application factory.

All blueprints registered here. Modules reserved for later phases
(documents, retrieval, agents, chat, observability, audit, analytics) are
intentionally NOT registered yet - see each module's __init__.py docstring.
"""
from flask import Flask

from app.config import get_config
from app.extensions import db, migrate, jwt, cors
from app.common.errors import register_error_handlers
from app.common.logging_config import configure_logging, register_request_id_middleware
from app.cli import register_cli


def create_app(env_name: str | None = None) -> Flask:
    app = Flask(__name__)
    app.config.from_object(get_config(env_name))

    # --- Extensions ---
    db.init_app(app)
    migrate.init_app(app, db)
    jwt.init_app(app)
    cors.init_app(
        app,
        resources={r"/api/*": {"origins": app.config["CORS_ORIGINS"]}},
        supports_credentials=True,
    )

    # --- Cross-cutting concerns ---
    configure_logging(app)
    register_request_id_middleware(app)
    register_error_handlers(app)
    register_cli(app)

    # --- Models must be imported before Flask-Migrate can detect them ---
    from app.rbac.models import Role                          # noqa: F401
    from app.auth.models import User, RefreshSession           # noqa: F401
    from app.providers.models import ProviderConfig            # noqa: F401

    # --- JWT callbacks ---
    _register_jwt_callbacks()

    # --- Blueprints (Phase 1 scope only) ---
    from app.health.routes import health_bp
    from app.auth.routes import auth_bp
    from app.providers.routes import providers_bp

    prefix = app.config["API_PREFIX"]
    app.register_blueprint(health_bp, url_prefix=f"{prefix}/health")
    app.register_blueprint(auth_bp, url_prefix=f"{prefix}/auth")
    app.register_blueprint(providers_bp, url_prefix=f"{prefix}/providers")

    return app


def _register_jwt_callbacks() -> None:
    from app.common.responses import error_response

    @jwt.unauthorized_loader
    def _missing_token(reason):
        return error_response("MISSING_TOKEN", reason, 401)

    @jwt.invalid_token_loader
    def _invalid_token(reason):
        return error_response("INVALID_TOKEN", reason, 401)

    @jwt.expired_token_loader
    def _expired_token(jwt_header, jwt_payload):
        token_type = jwt_payload.get("type", "token")
        return error_response("TOKEN_EXPIRED", f"The {token_type} has expired.", 401)

    @jwt.revoked_token_loader
    def _revoked_token(jwt_header, jwt_payload):
        return error_response("TOKEN_REVOKED", "This token has been revoked.", 401)
