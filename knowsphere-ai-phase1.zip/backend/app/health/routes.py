"""Health check endpoint — used by Docker healthchecks, load balancers, and uptime monitors."""
from flask import Blueprint
from sqlalchemy import text

from app.extensions import db
from app.common.responses import success_response

health_bp = Blueprint("health", __name__, url_prefix="/health")


@health_bp.get("")
def health_check():
    db_status = "ok"
    try:
        db.session.execute(text("SELECT 1"))
    except Exception:
        db_status = "unreachable"

    return success_response(
        data={"status": "ok", "database": db_status},
        message="KnowSphere AI backend is running.",
    )
