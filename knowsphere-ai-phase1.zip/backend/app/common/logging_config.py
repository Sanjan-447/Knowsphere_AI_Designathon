"""
Logging setup and per-request correlation ID.

Every request gets a UUID stored on flask.g and echoed back in the
X-Request-ID response header. This is included in the standardized response
envelope (app/common/responses.py) and is the join key that will later
correlate an HTTP request with its LangSmith trace, once agent phases land.
"""
import logging
import sys
import uuid

from flask import g, request


def configure_logging(app):
    level = getattr(logging, app.config.get("LOG_LEVEL", "INFO").upper(), logging.INFO)

    handler = logging.StreamHandler(sys.stdout)
    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)s | req=%(request_id)s | %(message)s"
    )
    handler.setFormatter(formatter)

    class RequestIdFilter(logging.Filter):
        def filter(self, record):
            try:
                record.request_id = getattr(g, "request_id", "-")
            except RuntimeError:
                # Outside of an application/request context (e.g. startup logs)
                record.request_id = "-"
            return True

    handler.addFilter(RequestIdFilter())

    root_logger = logging.getLogger()
    root_logger.handlers = [handler]
    root_logger.setLevel(level)

    app.logger.handlers = [handler]
    app.logger.setLevel(level)


def register_request_id_middleware(app):
    @app.before_request
    def _assign_request_id():
        g.request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))

    @app.after_request
    def _echo_request_id(response):
        response.headers["X-Request-ID"] = getattr(g, "request_id", "-")
        return response
