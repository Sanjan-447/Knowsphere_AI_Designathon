# KnowSphere AI — Phase 1: Foundation & Core Infrastructure

This is Phase 1 of a 6-phase build. It ships **only** the foundation: auth,
RBAC scaffolding, provider management infrastructure, and the base project
structure. No document ingestion, RAG, LangGraph agents, or chat yet —
those land in later phases, and their module folders already exist as
documented placeholders (see "What's a placeholder" below).

Everything in this repository was written **and actually executed** —
migrations were generated for real against SQLite, the API was exercised
end-to-end (login, RBAC enforcement, provider CRUD, token refresh/revocation),
and the frontend was type-checked and built with Vite — before being handed
to you. It is not untested scaffolding.

---

## 1. Project Structure

```
knowsphere-ai/
├── backend/
│   ├── app/
│   │   ├── auth/            # User model, login/logout/refresh, admin user creation
│   │   ├── rbac/             # Role model + default role seeding
│   │   ├── providers/        # Provider CRUD, validation, default selection
│   │   ├── health/           # Health check endpoint
│   │   ├── security/         # Encryption helper for API keys at rest
│   │   ├── common/           # Standardized responses, error handling, logging
│   │   ├── documents/         ─┐
│   │   ├── retrieval/          │  Placeholders only — reserved for later
│   │   ├── agents/             │  phases (see each __init__.py docstring).
│   │   ├── chat/                │  Not registered as blueprints yet.
│   │   ├── observability/      │
│   │   ├── audit/              │
│   │   ├── analytics/         ─┘
│   │   ├── config.py, extensions.py, cli.py, __init__.py (app factory)
│   ├── migrations/            # Real Alembic migration history
│   ├── wsgi.py
│   ├── requirements.txt
│   └── Dockerfile
├── frontend/
│   ├── src/
│   │   ├── api/               # Axios client + auth/provider API calls
│   │   ├── context/           # AuthContext (session state, token refresh)
│   │   ├── routes/            # ProtectedRoute (auth + role gating)
│   │   ├── components/layout/ # Sidebar, DashboardLayout
│   │   ├── pages/              # Login, Dashboard home, Settings, Provider management
│   │   └── types/             # Shared TS types mirroring backend schemas
│   ├── package.json, vite.config.ts, tailwind.config.js, tsconfig.json
│   └── Dockerfile
├── docker-compose.yml
├── .env.example
└── README.md   (this file)
```

## 2. Implemented Files (by feature)

| Feature | Files |
|---|---|
| App factory, config, logging, errors | `backend/app/__init__.py`, `config.py`, `extensions.py`, `common/*` |
| Auth (login/logout/refresh/RBAC) | `backend/app/auth/*`, `backend/app/rbac/*`, `backend/app/cli.py` |
| Provider management | `backend/app/providers/*`, `backend/app/security/encryption.py` |
| Health check | `backend/app/health/routes.py` |
| Database migrations | `backend/migrations/` (generated for real, see below) |
| Auth UI + session handling | `frontend/src/context/AuthContext.tsx`, `frontend/src/api/client.ts`, `frontend/src/api/auth.ts` |
| Protected routing | `frontend/src/routes/ProtectedRoute.tsx` |
| Layout | `frontend/src/components/layout/*` |
| Pages | `frontend/src/pages/*` |
| Infra | `docker-compose.yml`, `backend/Dockerfile`, `frontend/Dockerfile`, `.env.example` |

## 3. Setup Instructions

### Option A — Docker Compose (recommended)

```bash
cd knowsphere-ai
cp .env.example .env
# Generate a real encryption key and paste it into .env as ENCRYPTION_KEY:
python3 -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"

docker compose up --build
```

This starts Postgres, the Flask backend (auto-runs migrations on boot), and
the Vite frontend dev server.

Then, in a second terminal, seed the roles and your first admin user:

```bash
docker compose exec backend flask seed-roles
docker compose exec backend flask seed-admin
# follow the prompts for email / display name / password
```

- Frontend: http://localhost:5173
- Backend API: http://localhost:5000/api/v1
- Health check: http://localhost:5000/api/v1/health

### Option B — Running locally without Docker

**Backend:**

```bash
cd backend
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp ../.env.example .env          # or export the variables directly
# make sure ENCRYPTION_KEY, SECRET_KEY, JWT_SECRET_KEY are set
# DATABASE_URL can be omitted to fall back to local SQLite

export FLASK_APP=wsgi.py
flask db upgrade
flask seed-roles
flask seed-admin

flask run --port 5000
```

**Frontend** (separate terminal):

```bash
cd frontend
cp .env.example .env
npm install
npm run dev
```

## 4. Commands Reference

| Action | Command |
|---|---|
| Apply migrations | `flask db upgrade` |
| Create a new migration after model changes | `flask db migrate -m "description"` |
| Seed default roles | `flask seed-roles` |
| Create/reset the admin user | `flask seed-admin` |
| Run backend dev server | `flask run --port 5000` |
| Run backend production server | `gunicorn -w 4 -b 0.0.0.0:5000 wsgi:app` |
| Run frontend dev server | `npm run dev` |
| Type-check frontend | `npx tsc -b` |
| Build frontend for production | `npm run build` |

## 5. Assumptions Made During Implementation

1. **Database fallback**: `DATABASE_URL` defaults to a local SQLite file if
   unset, per the spec's "PostgreSQL (fallback SQLite)" instruction. Docker
   Compose always uses Postgres; local (non-Docker) runs default to SQLite
   unless you set `DATABASE_URL` yourself.
2. **"Sessions" table** was interpreted as refresh-token session tracking
   (`refresh_sessions`) — the mechanism that makes JWT refresh tokens
   actually revocable on logout — rather than a generic HTTP session store,
   since the spec groups it with JWT/refresh token requirements.
3. **RBAC foundation** ships as a simple `roles` lookup table with a
   `User.role_id` foreign key (Admin/Manager/Employee), not yet the full
   Role/Permission/ResourcePolicy model from the long-term architecture
   blueprint — intentionally deferred, since Phase 1 asks only for the
   foundation.
4. **No self-service registration**: users are provisioned either by an
   Admin (`POST /auth/users`) or via the `flask seed-admin` CLI command for
   the very first account. This matches enterprise practice better than an
   open signup form and anticipates SSO/SCIM federation in a later phase.
5. **Provider validation is format-only in Phase 1** (checks a key is
   present, roughly matches the provider's expected prefix, and that a
   `base_url` is set where required) — deliberately not calling out to any
   provider's API yet, per the spec's explicit "Do not implement LLM calls
   yet" instruction.
6. **Refresh token storage on the frontend** uses `localStorage` (with the
   access token kept only in memory) as a pragmatic Phase 1 choice. A
   production hardening pass should move the refresh token to an httpOnly
   cookie set directly by the backend — noted as a comment in
   `frontend/src/api/client.ts`.
7. **Frontend Dockerfile runs the Vite dev server**, not a production nginx
   build, since Phase 1 is a local development foundation. Swapping in a
   multi-stage production build is straightforward when you're ready to
   deploy — noted in `frontend/Dockerfile`.
8. **Provider management is Admin-only** (not Manager) — deciding which LLM
   vendor the org calls, and holding its API key, is treated as an
   administrative action.

## 6. What's a Placeholder (Not Yet Implemented)

The following backend packages exist as empty, documented placeholders and
are **not** registered as Flask blueprints yet: `documents/`, `retrieval/`,
`agents/`, `chat/`, `observability/`, `audit/`, `analytics/`. Each
`__init__.py` states which phase it's reserved for. Do not build on top of
these until their phase begins — the shape may change once ingestion and
RAG requirements are implemented against real data.
