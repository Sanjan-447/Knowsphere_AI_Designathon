import { apiClient, getRefreshToken } from "@/api/client";
import type { ApiResponse, LoginResponse, User } from "@/types";

export async function login(email: string, password: string) {
  const res = await apiClient.post<ApiResponse<LoginResponse>>("/auth/login", { email, password });
  if (!res.data.success) throw new Error(res.data.error.message);
  return res.data.data;
}

export async function logout() {
  const refreshToken = getRefreshToken();
  if (!refreshToken) return;
  try {
    await apiClient.post<ApiResponse<null>>(
      "/auth/logout",
      {},
      { headers: { Authorization: `Bearer ${refreshToken}` } }
    );
  } catch {
    // Best-effort — proceed with local logout regardless.
  }
}

export async function fetchMe() {
  const res = await apiClient.get<ApiResponse<User>>("/auth/me");
  if (!res.data.success) throw new Error(res.data.error.message);
  return res.data.data;
}
