import { useAuth } from "@/context/AuthContext";

export function DashboardHomePage() {
  const { user } = useAuth();

  return (
    <div className="mx-auto max-w-2xl px-10 py-16 text-center">
      <div className="font-display text-2xl font-semibold text-ink">
        Welcome, {user?.display_name?.split(" ")[0]}
      </div>
      <p className="mx-auto mt-3 max-w-md text-sm text-[#6B6558]">
        You're signed in as <span className="font-medium text-ink">{user?.role}</span>. This is Phase 1 of
        KnowSphere AI — foundation and core infrastructure only.
      </p>
      <div className="mt-8 rounded border border-dashed border-rule bg-white/60 px-6 py-5 text-left text-sm text-[#6B6558]">
        <p className="mb-2 font-medium text-ink">Coming in later phases:</p>
        <ul className="list-inside list-disc space-y-1">
          <li>Document upload and the Enterprise RAG ingestion pipeline</li>
          <li>The chat experience with cited, grounded answers</li>
          <li>LangGraph multi-agent workflow</li>
          <li>Analytics dashboard and audit log viewer</li>
        </ul>
      </div>
      {user?.role === "admin" && (
        <p className="mt-6 text-xs text-[#6B6558]">
          As an admin, you can configure LLM providers under{" "}
          <span className="font-medium text-ink">Provider settings</span> in the sidebar.
        </p>
      )}
    </div>
  );
}
