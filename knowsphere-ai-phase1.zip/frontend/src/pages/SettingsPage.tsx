import { Link } from "react-router-dom";

export function SettingsPage() {
  return (
    <div className="mx-auto max-w-2xl px-10 py-10">
      <h1 className="font-display text-xl font-semibold text-ink">Settings</h1>
      <p className="mt-1 text-sm text-[#6B6558]">
        Organization-level configuration. More sections (org profile, security policies, LangSmith
        observability) arrive in later phases.
      </p>

      <Link
        to="/settings/providers"
        className="mt-6 flex items-center justify-between rounded border border-rule bg-white px-5 py-4 transition-colors hover:border-gold"
      >
        <div>
          <div className="font-medium text-ink">LLM provider management</div>
          <div className="text-sm text-[#6B6558]">
            Connect OpenAI, Anthropic, Gemini, and other providers; choose the default.
          </div>
        </div>
        <span className="text-gold">→</span>
      </Link>
    </div>
  );
}
