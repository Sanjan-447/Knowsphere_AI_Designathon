// Mirrors app/common/responses.py — every API call returns one of these two shapes.
export interface ApiSuccess<T> {
  success: true;
  data: T;
  message: string;
  request_id: string | null;
}

export interface ApiError {
  success: false;
  error: {
    code: string;
    message: string;
    details?: unknown;
  };
  request_id: string | null;
}

export type ApiResponse<T> = ApiSuccess<T> | ApiError;

export type Role = "admin" | "manager" | "employee";

export interface User {
  id: number;
  email: string;
  display_name: string;
  role: Role;
  is_active: boolean;
  created_at: string;
  last_login_at: string | null;
}

export interface LoginResponse {
  user: User;
  access_token: string;
  refresh_token: string;
}

export type ProviderType =
  | "openai"
  | "anthropic"
  | "gemini"
  | "groq"
  | "openrouter"
  | "nvidia_nim"
  | "ollama"
  | "openai_compatible";

export interface ProviderConfig {
  id: number;
  display_name: string;
  provider_type: ProviderType;
  api_key: string | null; // masked unless explicitly revealed
  base_url: string | null;
  extra_config: Record<string, unknown> | null;
  is_active: boolean;
  is_default: boolean;
  last_validated_at: string | null;
  last_validation_status: "passed" | "failed" | null;
  created_at: string;
  updated_at: string;
}

export interface SupportedProviderMeta {
  label: string;
  key_prefix: string | null;
  requires_base_url: boolean;
}
