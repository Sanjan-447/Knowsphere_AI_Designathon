import { NavLink } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";

const NAV_ITEMS = [
  { to: "/", label: "Dashboard", roles: ["admin", "manager", "employee"] },
  { to: "/settings/providers", label: "Provider settings", roles: ["admin"] },
];

export function Sidebar() {
  const { user, logout } = useAuth();

  return (
    <aside className="flex h-screen w-56 flex-shrink-0 flex-col bg-ink py-6 text-paper">
      <div className="border-b border-white/10 px-5 pb-5">
        <div className="font-display text-xl font-semibold">
          Knowsphere<span className="text-gold"> AI</span>
        </div>
        <div className="mt-1 text-[10px] tracking-wide text-white/50">
          Enterprise knowledge assistant
        </div>
      </div>

      <nav className="mt-2 flex-1">
        {NAV_ITEMS.filter((item) => !user || item.roles.includes(user.role)).map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.to === "/"}
            className={({ isActive }) =>
              `block border-l-[3px] px-5 py-3 text-sm font-medium transition-colors ${
                isActive
                  ? "border-gold bg-gold/10 text-paper"
                  : "border-transparent text-white/60 hover:bg-white/5 hover:text-paper"
              }`
            }
          >
            {item.label}
          </NavLink>
        ))}
      </nav>

      <div className="border-t border-white/10 px-5 pt-4">
        <div className="mb-3 text-xs text-white/70">
          <div className="font-medium text-paper">{user?.display_name}</div>
          <div className="text-white/40">{user?.role}</div>
        </div>
        <button
          onClick={() => logout()}
          className="w-full rounded border border-white/15 py-2 text-xs font-medium text-white/70 transition-colors hover:bg-white/5 hover:text-paper"
        >
          Log out
        </button>
      </div>
    </aside>
  );
}
