import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/context/AuthContext";
import { ProtectedRoute } from "@/routes/ProtectedRoute";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { LoginPage } from "@/pages/LoginPage";
import { DashboardHomePage } from "@/pages/DashboardHomePage";
import { SettingsPage } from "@/pages/SettingsPage";
import { ProviderManagementPage } from "@/pages/ProviderManagementPage";

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          <Route path="/login" element={<LoginPage />} />

          <Route element={<ProtectedRoute />}>
            <Route element={<DashboardLayout />}>
              <Route path="/" element={<DashboardHomePage />} />
              <Route path="/settings" element={<SettingsPage />} />

              <Route element={<ProtectedRoute allowedRoles={["admin"]} />}>
                <Route path="/settings/providers" element={<ProviderManagementPage />} />
              </Route>
            </Route>
          </Route>
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
}
